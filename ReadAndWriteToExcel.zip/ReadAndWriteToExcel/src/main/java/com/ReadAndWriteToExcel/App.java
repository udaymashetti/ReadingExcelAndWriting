package com.ReadAndWriteToExcel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.poi.ss.usermodel.CellCopyPolicy;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class App

{
	public static final String SAMPLE_XLSX_FILE_PATH = "./Regions.xlsx";

	public static void main(String[] args) {
		FileInputStream excelFile = null;
		FileOutputStream outputStream = null;
		Workbook workbook = null;
		int activeSheetIndex;
		XSSFSheet activeSheet;
		Iterator<?> sheetItr;
		LinkedHashMap<String, ArrayList<XSSFRow>> sheetAndRowsMap = new LinkedHashMap<String, ArrayList<XSSFRow>>();
		
		try {
			excelFile = new FileInputStream(new File(SAMPLE_XLSX_FILE_PATH));
			workbook = new XSSFWorkbook(excelFile);
			activeSheetIndex = workbook.getActiveSheetIndex();
			activeSheet = (XSSFSheet) workbook.getSheetAt(activeSheetIndex);
			sheetItr = activeSheet.rowIterator();
			int index = 0;
			XSSFRow headerRow = null;
			while (sheetItr.hasNext()) {
				XSSFRow row = (XSSFRow) sheetItr.next();
				if (index == 0) {
					headerRow = row;
//					headerRow.setRowNum(1);
					index++;
					continue;
				}
				XSSFCell cell = row.getCell(1);
				String cellValue = cell.getStringCellValue();
				if (cellValue != null && !cellValue.isEmpty() ) {
					if (sheetAndRowsMap.containsKey(cellValue)) {
						sheetAndRowsMap.get(cellValue).add(row);

					} else {
						ArrayList<XSSFRow> listOfRows = new ArrayList<XSSFRow>();
//						listOfRows.add(headerRow);
						listOfRows.add(row);
						sheetAndRowsMap.put(cellValue, listOfRows);
					} 
				}

			}
			for (Map.Entry<String, ArrayList<XSSFRow>> entry : sheetAndRowsMap.entrySet()) {
				String sheetName = "";
				try {
					sheetName = entry.getKey();
					XSSFSheet s = (XSSFSheet) workbook.createSheet(sheetName);
					CellCopyPolicy cellCpyPolicy = new CellCopyPolicy();
					cellCpyPolicy.setCondenseRows(true);
					s.copyRows(entry.getValue(), 0, cellCpyPolicy);	
					XSSFRow r = s.createRow(0);
					//r.copyRowFrom(headerRow, cellCpyPolicy);
					
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					System.out.println(sheetName + "  Already Exists in workbook");
					e.printStackTrace();
				}
			}
			outputStream = new FileOutputStream(new File(SAMPLE_XLSX_FILE_PATH));
			workbook.write(outputStream);

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Input Excel '" + SAMPLE_XLSX_FILE_PATH
					+ "' File Not found in project working directory " + System.getProperty("user.dir"));
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (excelFile != null)
					excelFile.close();
				if (workbook != null)
					workbook.close();
				if (outputStream != null)
					outputStream.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
}
